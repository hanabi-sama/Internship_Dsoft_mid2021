def main():
    #problem 1
    ls = [10,2,4,5,6]
    print("sum of ls",sum(ls))
    #problem 2
    print("largest number in list ",max(ls))
    #problem 3
    ls3 = [10,2,3,4,5,1,2,3]
    lsTemp = []
    for i in ls3:
        if i not in lsTemp:
            lsTemp.append(i)
    ls3 = lsTemp
    print(ls3)
    #problem 4
    if len(ls) == 0:
        print("empty")
    else:
        print("not empty")
    #problem 5
    ls.remove(max(ls))
    print("second largest in ls ",max(ls))
    #problem 6
    #ls = [2,4,5,6] after problem 5
    ls6 = [10,2,4]
    lsBoth = [i for i in ls if i in ls6]
    print("common elements between ls and ls6 ",lsBoth)
    #problem 7
    print("insert in posion 3rd with value : 4")
    ls.insert(3,4)
    print("elements after insert",ls)
    #problem 7
    ls7 = [5,6]
    print("elements after remove all elements in ls7 ")
    lsAfterRemove = [i for i in ls if i not in ls7]
    print(ls)
    #problem 8
    ls8 = [8,9]
    ls.extend(ls8)
    print("ls after append all elements in ls8 : ",ls)
main()
