#problem 1
def getMax(num1,num2,num3):
    max = num1
    if max < num2:
        max = num2
    if max < num3:
        max = num3
    return max
#problem 2
def multiplyNumInList(ls):
    product = 1
    for i in ls:
        product *= i
    return product
#problem 3
def isNumberInList(num,ls):
    for i in ls:
        if num == i:
            return True
    else:
        return False
#problem 4
def getUniqueList(ls):
    lsTemp = []
    for i in ls:
        if i not in lsTemp:
            lsTemp.append(i)
    ls = lsTemp
    return lsTemp
#problem 5
def isNumberPrime(num):
    if num == 1:
        return False
    temp = 0
    for i in range(1,round(num/2)+1,1):
        if num % i ==0:
            temp +=1
    if temp >=2:
        return False
    else:
        return True
#problem 5
def getEvenNumber(ls):
    lsTemp = [i for i in ls if i % 2 == 0]
    return lsTemp
#problem 6
def isStringPalindrome(str):
    reverseStr = ""
    for i in range(len(str)-1,-1,-1):
        reverseStr += str[i]
    if reverseStr == str:
        return True
    else:
        return False


