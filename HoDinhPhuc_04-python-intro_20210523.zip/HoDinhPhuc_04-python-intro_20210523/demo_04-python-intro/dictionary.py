import json
def main():
    #problem 1
    dict = {"name":"phuc","age":21}
    dict["school"] = "DUT"
    print("dict after add key school and value DUT",dict)
    #problem 2
    key = ""
    for i in dict:
        if key == i:
            print("yes")
    else:
        print("no")
    #problem 3
    for i in dict:
        print(i,dict[i])
    #problem 4
    dict4 = {"math" : 10,"chemical":9}
    dictBoth = dict.copy()
    dictBoth = dictBoth.update(dict4)
    print(dictBoth)
    #problem 5
    dict5 = {"literature":7,"English":8}
    dict5.pop("literature")
    print("dict5 after remove key literature ",dict5)
    #problem 6
    dict6 = {}
    if len(dict6) == 0:
        print("empty")
    else:
        print("not empty")
    #problem 7
    with open("dict.json","w") as f:
        json.dump(dict,f)
main()