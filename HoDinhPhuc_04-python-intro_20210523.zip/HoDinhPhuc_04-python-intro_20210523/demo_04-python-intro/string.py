#problem 4
def getLongestString(ls):
    max = ""
    for i in ls:
        if len(i)>len(max):
            max = i
    return max
#problem 5
def addTags(tag,words):
    if tag =="b":
        print("\033[01m" + words + "\033[0m")
    if tag =="i":
        print("\033[03m" + words + "\033[0m")
#problem 6
def getReversedString(str):
    reverseStr = ""
    if len(str) %4 == 0:
        for i in range(len(str)-1,-1,-1):
            reverseStr += str[i]
    return reverseStr
def main():
    #problem 1
    str = "phuc"
    print("length of str",len(str))
    #problem 2
    str2 = "google.com"
    count = {}
    for i in str2:
        if i in count:
            count[i] += 1
        else:
            count[i] = 1
    print(count)
    #problem 3
    str3 = "gooing"
    if len(str3) >=3:
        if str3[len(str3)-3:len(str3)] == "ing":
            str3 += "ly"
        else:
            str +="ing"
    print(str3)
    #problem 4
    ls = ["phuc","21","DUT","handsome boy"]
    max = getLongestString(ls)
    print(max,len(max))
    #problem 5
    addTags("i","phuc")
    #problem 6
    str6 = "phuc"
    print("str6 after reverse :",getReversedString(str6))
    #problem 7
    str = "phuc"
    str.startswith("p")
main()