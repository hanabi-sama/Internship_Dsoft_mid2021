def main():
    #problem 1
    tup = ("phuc",21,"DUT")
    (name,age,school) = tup
    print(name)
    #problem 2
    tup2 = ("phuc",21,"DUT")
    tup2 += ("handsome boy",)
    print("tup2 after add ",tup2)
    #problem 3
    ele = 22
    for i in tup2:
        if ele == i:
            print("yes")
    else:
        print("no")
    #problem 4
    ls = [10,2,3]
    tup4 = tuple(ls)
    print(tup4)
    #problem 5
    print("elements from 1st to 3rd in tup4",tup4[:3])
    #problem 6
    tup6 = tuple("phuc")
    print("poisition of h in tup 6",tup6.index("h"))
main()