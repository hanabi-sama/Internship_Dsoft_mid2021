"""Test module calculator."""
import unittest
from src.calculator import Calculator

"""Test calculator class."""


class TestCalculator(unittest.TestCase):
    """Body TestCalculator."""

    def setUp(self) -> None:
        """Ignore call before."""
        self.cal = Calculator()

    def test_add(self):
        """Test add function."""
        args = (2, 2)
        self.assertEqual(self.cal.add(*args), 4)
        args = (3, 2)
        self.assertEqual(self.cal.add(*args), 5)
        args = (5, 2)
        self.assertEqual(self.cal.add(*args), 7)

    def test_sub(self):
        """Test subtract function."""
        args = (2, 2)
        self.assertEqual(self.cal.sub(*args), 0)
        args = (3, 2)
        self.assertEqual(self.cal.sub(*args), 1)
        args = (5, 2)
        self.assertEqual(self.cal.sub(*args), 3)

    def test_mul(self):
        """Test multiply function."""
        args = (2, 2)
        self.assertEqual(self.cal.mul(*args), 4)
        args = (3, 2)
        self.assertEqual(self.cal.mul(*args), 6)
        args = (5, 2)
        self.assertEqual(self.cal.mul(*args), 10)

    def test_div(self):
        """Test divide function."""
        args = (2, 0)
        self.assertEqual(self.cal.div(
            *args), "invalid input value")
        args = (4, 2)
        self.assertEqual(self.cal.div(*args), 2.0)
        args = (0, 0)
        self.assertEqual(self.cal.div(*args), "invalid input value")

    def test_power(self):
        """Test power function."""
        args = (4, 2)
        self.assertEqual(self.cal.power(*args), 16)
        args = (2, 2)
        self.assertEqual(self.cal.power(*args), 4)
        args = (0, 0)
        self.assertEqual(self.cal.power(*args), 1)

    def test_linear(self):
        """Test linear function."""
        args = (0, 4)
        self.assertEqual(self.cal.linear(*args), "no value")
        args = (0, 0)
        self.assertEqual(self.cal.linear(*args), "infinite")
        args = (4, 2)
        self.assertEqual(self.cal.linear(*args), -0.5)

    def test_quadractic_eq_solvers(self):
        """Test quadractic_eq_solvers function."""
        args = (2, -3, 1)
        self.assertEqual(
            self.cal.quadractic_eq_solvers(*args), (0.5, 1))
        args = (1, -2, 1)
        self.assertEqual(
            self.cal.quadractic_eq_solvers(*args), (1, 1))
        args = (3, 2, 1)
        self.assertEqual(
            self.cal.quadractic_eq_solvers(*args), "no value")
        args = (0, 1, 2)
        self.assertEqual(
            self.cal.quadractic_eq_solvers(*args), -2.0)
        args = (0, 0, 1)
        self.assertEqual(
            self.cal.quadractic_eq_solvers(*args), "no value")
        args = (0, 0, 0)
        self.assertEqual(
            self.cal.quadractic_eq_solvers(*args), "infinite")


if __name__ == '__main__':
    unittest.main()
