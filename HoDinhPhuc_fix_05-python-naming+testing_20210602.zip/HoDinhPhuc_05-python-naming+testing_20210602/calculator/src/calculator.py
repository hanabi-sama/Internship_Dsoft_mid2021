"""Calculator module."""


class Calculator(object):
    """Calculator feature."""

    def __init__(self):
        """Init."""
        super().__init__()

    def add(self, val_1, val_2):
        """Add 2 arguments."""
        return val_1 + val_2

    def sub(self, val_1, val_2):
        """Subtract 2 arguments."""
        return val_1 - val_2

    def mul(self, val_1, val_2):
        """Multiply 2 arguments."""
        return val_1 * val_2

    def div(self, val_1, val_2):
        """Divide 2 arguments."""
        if val_2 == 0:
            return "invalid input value"
        else:
            return val_1 / val_2

    def power(self, base, exponent):
        """Power base with exponent."""
        return pow(base, exponent)

    def linear(self, w, b):
        """Get result of wx + b = 0."""
        if w == 0:
            if b == 0:
                return "infinite"
            else:
                return "no value"
        else:
            return -b/w

    def quadractic_eq_solvers(self, a, b, c):
        """Get result of ax^2 + bx + c = 0."""
        if a == 0:
            return Calculator.linear(self, b, c)
        else:
            delta = pow(b, 2) - 4*a*c
            if delta >= 0:
                return (-b-pow(delta, 0.5))/(2*a), (-b+pow(delta, 0.5))/(2*a)
            else:
                return "no value"


"""Main processing"""


def main():
    """Do calculation."""
    cal = Calculator()
    while(True):
        print("please choose the equation you want bruh : ")
        print("press 1 : for addition")
        print("press 2 : for subtraction")
        print("press 3 : for multiple")
        print("press 4 : for divice")
        print("press 5 : for power")
        print("press 6 : for linear")
        print("press 7 : quadractic equation solvers")
        choice = int(input("press your choice : "))
        if choice in range(1, 8, 1):
            if choice in range(1, 6, 1):
                val_1 = int(input("the first value is : "))
                val_2 = int(input("the second value is : "))
                if choice == 1:
                    print(val_1, "+", val_2, "=", cal.add(val_2, val_1))
                    break
                if choice == 2:
                    print(val_1, "-", val_2, "=", cal.sub(val_1, val_2))
                    break
                if choice == 3:
                    print(val_1, "*", val_2, "=", cal.mul(val_1, val_2))
                    break
                if choice == 4:
                    print(val_1, "/", val_2, "=", cal.div(val_1, val_2))
                    break
                if choice == 5:
                    print(val_1, "^", val_2, "=",
                          cal.power(val_1, val_2))
                    break
            elif choice == 6:
                w = int(input("enter value of weight : "))
                b = int(input("enter the value of bias: "))
                print(cal.linear(w, b))
                break
            else:
                val_1 = int(input("enter the value of x^2 : "))
                val_2 = int(input("enter the value of x : "))
                val_3 = int(input("enter the value of x^0 : "))
                print("pair of result of equation",
                      cal.quadractic_eq_solvers(val_1, val_2, val_3))
                break
        else:
            print("invalid choice")


if __name__ == "__main__":
    main()
